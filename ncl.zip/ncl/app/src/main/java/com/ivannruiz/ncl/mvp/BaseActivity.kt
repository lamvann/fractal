package com.ivannruiz.ncl.mvp

import androidx.appcompat.app.AppCompatActivity

// TODO implement composite disposable
abstract class BaseActivity : AppCompatActivity() {

    var isOnBackground: Boolean = false
        private set

    override fun onResume() {
        super.onResume()
        isOnBackground = false
    }

    override fun onPause() {
        super.onPause()
        isOnBackground = true
    }
}
