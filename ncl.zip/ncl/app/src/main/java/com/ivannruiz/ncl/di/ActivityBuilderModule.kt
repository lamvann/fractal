package com.ivannruiz.ncl.di

import com.ivannruiz.ncl.LoadShipActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBuilderModule {

    @ContributesAndroidInjector
    abstract fun contributesLoadShipActivity(): LoadShipActivity
}
